# pip install streamlit numpy sentence_transformers pandas pydantic scikit-learn fastapi uvicorn
# #!/bin/bash
# source venv/bin/activate
# exec streamlit run svc_train_app.py --server.port 8000 --server.address 0.0.0.0
#!/bin/bash
# Activate venv (Azure will usually activate automatically)
# source venv/bin/activate    # Uncomment only if using local venv
supervisord -c supervisord.conf
